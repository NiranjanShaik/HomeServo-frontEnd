// nav js code
let customer= document.getElementById("customer");
console.log(customer);
//customer functionality
customer.addEventListener("click", ()=>{
    // console.log("hello")
    let demo= document.getElementById("sub-nav1");
    console.log(demo);
    let display= demo.classList.toggle("true");
    if(display){
        demo.style.display= "block";
    }
    else{
        demo.style.display= "none";
    }
})

//vendor functionality
let vendor= document.getElementById("vendor");
console.log(vendor);

vendor.addEventListener("click", ()=>{
    // console.log("hello")
    let demo1= document.getElementById("sub-nav2");
    console.log(demo1);
    let display= demo1.classList.toggle("true");
    if(display){
        demo1.style.display= "block";
    }
    else{
        demo1.style.display= "none";
    }
})

//for password

let str= "Ram@1234567";

let reg= /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
console.log(reg.test(str));

//code starts for service functionality
let service= document.getElementById("service");
service.addEventListener("click", ()=>{
    let drop_down= document.querySelector("#drop-down");
    console.log(drop_down);
    let display= drop_down.classList.toggle("block");
    if(display){
        drop_down.style.display= "block";
    }
    else{
        drop_down.style.display= "none";
    }
})

