let btn = document.getElementById("btn")
console.log(btn);


btn.addEventListener("click" , (e) => {
   e.preventDefault()
   let span = document.getElementsByTagName("span")
   console.log(span);
   let workId = document.getElementById("workId").value
   // console.log(workId);
   let vendorId = document.getElementById("VendorId").value
   // console.log(vendorId);
   let cost = document.getElementById("costperday");

   
   
   if(workId === "")
   {
      span[1].style.display = "block"
   }
   else if(vendorId === "")
   {
    span[3].style.display = "block"
   }else if(cost === ""){
    span[5].style.display = "block"
   }

})

let startwork = async() => {
    let workId = document.getElementById("workId").value
    let vendorId = document.getElementById("VendorId").value
   let cost = document.getElementById("costperday").value
   
    let response= await fetch("http://localhost:8080/savecost/" +vendorId+ "/" + workId ,{
      method: "POST",
      headers: {
         "Accept": "application/json",
         "Content-Type": "application/json"
      },
      body: JSON.stringify({
         totalAmount:cost
      })
   })

   if(response.status === 201){
    window.alert("COST SAVED successfully") ;

 }else{
    window.alert("plz check the details it seems you entered wrong details")
 }
}

btn.addEventListener("click" ,  startwork);