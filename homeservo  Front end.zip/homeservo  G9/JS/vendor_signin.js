
let btn = document.getElementById("btn")
var email ;
var pwd ;
 btn.addEventListener("click",(e) => {
    e.preventDefault()
    let span = document.getElementsByTagName("span")

    email = document.getElementById("email").value
   console.log(email);

 pwd = document.getElementById("password").value
   console.log(password);

   if(email === ""){
    span[1].style.display = "block"
    }
    else if(password === "")
    {
     span[3].style.display = "block"
    }


})
let signin = async() => {
    
    const url = ("http://localhost:8080/loginvendor/"+ email + "/" + pwd ) ;

    let options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
         }
    }

    try {
        let response = await fetch(url, options);
    
        if (response.ok) {
            window.alert("login done succesfully");
        }
    
        var vendor = await response.json(); 
        console.log(vendor);
    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
    const jsonData = JSON.stringify(vendor);
    console.log(jsonData);
    sessionStorage.setItem('vendordata', jsonData);

     const storedData = sessionStorage.getItem('vendordata');
    // console.log(storedData);
    if (storedData!=null) {
        console.log(storedData);
    const parsedData = JSON.parse(storedData);
    window.alert("data stored in local session")
    document.cookie = sessionStorage.getItem('vendordata');
    window.location.href = "http://127.0.0.1:5500/LifV1.html";

    }

    else {
        console.log('no profile found');
    }

    }

btn.addEventListener("click",signin)


