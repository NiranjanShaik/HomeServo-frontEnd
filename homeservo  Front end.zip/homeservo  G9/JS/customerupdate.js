// customer_update js code
let btn = document.getElementById("btn")
console.log(btn);

const urlParams = new URLSearchParams(window.location.search);
const data = urlParams.get('customerdata');
document.cookie = sessionStorage.getItem('customerdata');

console.log(sessionStorage.getItem('customerdata'));
var custom = sessionStorage.getItem('customerdata') ;
console.log(typeof custom);
var jsonobject = JSON.parse(custom) ;
console.log(typeof jsonobject);
console.log(jsonobject["data"]["id"]);
var id = jsonobject["data"]["id"] ;
console.log(id);

btn.addEventListener("click" , (e) => {
   e.preventDefault()
   let span = document.getElementsByTagName("span")
   console.log(span);
   let user = document.getElementById("user-name").value
   console.log(user);
   let email = document.getElementById("email").value
   console.log(email);
   let phone = document.getElementById("phone").value
   console.log(phone);
   let password = document.getElementById("password").value
   console.log(password);
    
    
    
   
   let family = document.getElementById("family-count").value
   console.log(family);
   let door = document.getElementById("door-no").value
   console.log(door);
   let street = document.getElementById("street").value
   console.log(street);
   let land = document.getElementById("land-mark").value
   console.log(land);
   let district = document.getElementById("district").value
   console.log(district);
   let state = document.getElementById("state").value
   console.log(state);
   let pin = document.getElementById("pin-code").value
   console.log(pin);
   
   if(user === "")
   {
      span[1].style.display = "block"
   }
   else if(email === "")
   {
    span[3].style.display = "block"
   }else if(phone === ""){
    span[5].style.display = "block"
   }else if(password === ""){
    span[7].style.display = "block"
   }else if(family === ""){
    span[9].style.display = "block"
   }else if(door === ""){
      span[11].style.display = "block"
   }else if(street === ""){
    span[13].style.display = "block"
   }else if(land === ""){
    span[15].style.display = "block"
   }else if(district === ""){
    span[17].style.display = "block"
   }else if(state === ""){
    span[19].style.display = "block"
   }else if(pin === ""){
    span[21].style.display = "block"
   }
  
   
   
})

const password= document.getElementById("password");
password.addEventListener("input", ()=>{
   const passText= document.querySelector(".passText");
   const passPattern= /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;

   if(password.value.match(passPattern)){
      passText.innerHTML="your password is valid";
      passText.style.color="green";
   }
   else{
      passText.innerHTML= "your password must contain atleast 8 characters, one uppercase, one lowercase, one number and one special character";

   }
});

let saveCustomer= async() =>{
   let user = document.getElementById("user-name").value
let email = document.getElementById("email").value
let phone = document.getElementById("phone").value
let password = document.getElementById("password").value
let family = document.getElementById("family-count").value
let door = document.getElementById("door-no").value
let street = document.getElementById("street").value
let land = document.getElementById("land-mark").value
let district = document.getElementById("district").value
let state = document.getElementById("state").value
let pin = document.getElementById("pin-code").value

   let response= await fetch("http://localhost:8080/updatecustomer", {
      method: "PUT",
      headers: {
         "Accept": "application/json",
         "Content-Type": "application/json"
      },
      body: JSON.stringify({

            id : id ,
            name: user,
            email: email,
            phone: phone,
            pwd: password,
            familyCount: family,
            address:{
                doorNumber: door,
                street: street,
                landMark: land,
                district: district,
                state: state,
                pinCode: pin
            }
        
      })
   })
   console.log(response);

   if(response.status === 302){
      window.alert(user +" updated successfully")
      window.location.href = "http://127.0.0.1:5500/customer_signin.html" ;

   }

   
}

btn.addEventListener("click", saveCustomer);