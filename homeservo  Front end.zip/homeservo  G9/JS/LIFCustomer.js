// login interface customer java script code

let works=document.getElementById("works")

console.log(works);

works.addEventListener("click",()=>{
  let drop_down=document.querySelector("#drop-down")
  console.log(drop_down);

  let display=drop_down.classList.toggle("none")
  if(display){
    drop_down.style.display="block"
  }
  else{
    drop_down.style.display="none"
  }
})







let getdetails= document.getElementById("customerdetails");
const urlParams = new URLSearchParams(window.location.search);
const data = urlParams.get('customerdata');
console.log(data);
document.cookie = sessionStorage.getItem('customerdata');

console.log(sessionStorage.getItem('customerdata'));
var custom = sessionStorage.getItem('customerdata') ;
console.log(typeof custom);
var jsonobject = JSON.parse(custom) ;
console.log(typeof jsonobject);
console.log(jsonobject["data"]["id"]);
var id = jsonobject["data"]["id"] ;
console.log(typeof id);

let getcustomerbyid = async() => {
    
    const url = ("http://localhost:8080/getcustomerbyid/" + id ) ;

    let options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
         }
    }

    try {
        let response = await fetch(url, options);
        console.log(response);
        var customer = await response.json();
        var cusid = customer["data"]["id"] ;
        var name = customer["data"]["name"] ;
        var phone = customer["data"]["phone"] ;
        var email = customer["data"]["email"] ;
        
        const datacontainer = document.getElementById("data-container");
        datacontainer.innerHTML = `
        id : ${cusid}<br>
        Name: ${name} <br>
        Email : ${email} <br>
        phone : ${phone}
        `;

        let demo1= document.getElementById("drop-down2");
        console.log(demo1);
        let display= demo1.classList.toggle("true");
        if(display){
            demo1.style.display= "block";
        }
        else{
            demo1.style.display= "none";
        }

        let demo2= document.getElementById("data-container");
        console.log(demo1);
        let display1= demo2.classList.toggle("true");
        if(display1){
            demo1.style.display1= "block";
        }
        else{
            demo1.style.display1= "none";
        }
        
    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
    const jsonData = JSON.stringify(customer);
    console.log(jsonData);
   

    }

getdetails.addEventListener("click",getcustomerbyid)

// let service= document.getElementById("service");
// service.addEventListener("click", ()=>{
//     let drop_down= document.querySelector("#drop-down");
//     console.log(drop_down);
//     let display2= drop_down.classList.toggle("block");
//     if(display2){
//         drop_down.style.display2= "block";
//     }
//     else{
//         drop_down.style.display2= "none";
//     }
// })






