// login interface vendor java script code


let works=document.getElementById("works")

// console.log(works);

works.addEventListener("click",()=>{
  let drop_down=document.querySelector("#drop-down")
//   console.log(drop_down);

  let display=drop_down.classList.toggle("none")
  if(display){
    drop_down.style.display="block"
  }
  else{
    drop_down.style.display="none"
  }
})

let getdetails= document.getElementById("vendordetails");
const urlParams = new URLSearchParams(window.location.search);
const data = urlParams.get('vendordata');
document.cookie = sessionStorage.getItem('vendordata');

// console.log(sessionStorage.getItem('vendordata'));
var custom = sessionStorage.getItem('vendordata') ;
// console.log(typeof custom);
var jsonobject = JSON.parse(custom) ;
// console.log(typeof jsonobject);
// console.log(jsonobject["data"]["id"]);
var id = jsonobject["data"]["id"] ;
// console.log(typeof id);



let getvendorbyid = async() => {
    
    const url = ("http://localhost:8080/getvendorbyid/" + id ) ;

    let options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
         }
    }

    try {
        let response = await fetch(url, options);
        // console.log(response);
        var vendor = await response.json(); 
        var name = vendor["data"]["name"] ;
        var phone = vendor["data"]["phone"] ;
        var email = vendor["data"]["email"] ;
        const datacontainer = document.getElementById("data-container");
        datacontainer.innerHTML = `
        id : ${id} <br>
        Name: ${name} <br>
        Email : ${email} <br>
        phone : ${phone}
        `;

        let demo1= document.getElementById("sub-nav2");
        // console.log(demo1);
        let display= demo1.classList.toggle("true");
        if(display){
            demo1.style.display= "block";
        }
        else{
            demo1.style.display= "none";
        }

        let demo2= document.getElementById("data-container");
        console.log(demo2);
        let display1= demo2.classList.toggle("true");
        if(display1){
            demo1.style.display1= "block";
        }
        else{
            demo1.style.display1= "none";
        }


    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
    const jsonData = JSON.stringify(vendor);
    // console.log(jsonData);
   

    }

getdetails.addEventListener("click" , getvendorbyid);

let availworks = document.getElementById("availworks") ;

let availableworks = async() => {
    
  
    const url = ("http://localhost:8080/getallwork/" + id ) ;

    let options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
         }
    }

    try {
        let response = await fetch(url, options);
        // console.log(response);
        var vendor = await response.json(); 
        
        let demo4= document.getElementById("sub-nav3");
        // console.log(demo4);
        let display= demo4.classList.toggle("true");
        if(display){
            demo4.style.display= "block";
        }
        else{
            demo4.style.display= "none";
        }
        let demo3= document.getElementById("data-container2");
        // console.log(demo3);
        let display3= demo3.classList.toggle("true");
        if(display3){
            demo3.style.display3= "block";
        }
        else{
            demo3.style.display3= "none";
        }

    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
    const jsonData = JSON.stringify(vendor);
    // console.log(jsonData);

    const parsedData = JSON.parse(jsonData);

// Access the 'data' key which contains an array of objects
    const dataList = parsedData.data;

// Now dataList contains a list of individual objects
    const datacontainer2 = document.getElementById("data-container2");
    dataList.forEach(item => {
        var workid = item["id"] ;
        var type = item["type"] ;
        var name = item["customer"]["name"] ;
        var phone = item["customer"]["phone"] ;
        var email = item["customer"]["email"] ;
        var d_no = item["customer"]["address"]["d_no"] ;
        var street = item["customer"]["address"]["street"] ;
        var landmark = item["customer"]["address"]["landmark"] ;
        var district = item["customer"]["address"]["district"] ;
        var state = item["customer"]["address"]["state"] ;
        var pincode = item["customer"]["address"]["pinCode"] ;
        const objectDiv = document.createElement('div');
        objectDiv.textContent = `workid : ${workid} , typeof work : ${type} ,Name: ${name} , email : ${email}, phone : ${phone} , d_no : ${d_no} , street : ${street} ,landmark : ${landmark} , district : ${district} state  : ${state}, pincode : ${pincode}`;
        datacontainer2.appendChild(objectDiv);
    });
    
   

    }
availworks.addEventListener("click" , availableworks);

