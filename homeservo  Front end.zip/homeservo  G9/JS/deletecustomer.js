// delete customer java script


const urlParams = new URLSearchParams(window.location.search);
const data = urlParams.get('customerdata');
document.cookie = sessionStorage.getItem('customerdata');

console.log(sessionStorage.getItem('customerdata'));
var custom = sessionStorage.getItem('customerdata') ;
console.log(typeof custom);
var jsonobject = JSON.parse(custom) ;
console.log(typeof jsonobject);
console.log(jsonobject["data"]["id"]);
var id = jsonobject["data"]["id"] ;
console.log(id);

let no = document.getElementById("no");
let yes = document.getElementById("yes");
no.addEventListener("click", function() {
    // Use the history object to navigate back to the previous page
    window.history.back();
});

let deleteCustomer = async() =>{
    
    const url = ("http://localhost:8080/deletecustomer/"+ id) ;

    let options = {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
         }
    }

    try {
        let response = await fetch(url, options);
        console.log(response.status);
        if (response.status === 302) {
            window.alert("Delete  done succesfully");
            window.location.href = "http://127.0.0.1:5500/customer_signup.html" ;
        }
    
    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
   

    }

   yes.addEventListener("click" , deleteCustomer) ;
 
    
 
