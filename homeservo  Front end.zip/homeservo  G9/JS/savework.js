let getdetails= document.getElementById("customerdetails");
const urlParams = new URLSearchParams(window.location.search);
const data = urlParams.get('customerdata');
document.cookie = sessionStorage.getItem('customerdata');
console.log(sessionStorage.getItem('customerdata'));
var custom = sessionStorage.getItem('customerdata') ;
console.log(typeof custom);
var jsonobject = JSON.parse(custom) ;
console.log(typeof jsonobject);
console.log(jsonobject["data"]["id"]);
var id = jsonobject["data"]["id"] ;
console.log(typeof id);

let work = document.getElementById("work");
work.addEventListener("click" , (e) => {
    e.preventDefault()
    let span = document.getElementsByTagName("span")
    console.log(span);
    let workentered = document.getElementById("typeofwork").value
    console.log(workentered);
  

    if(workentered === "")
    {
       span[1].style.display = "block"
    }
    
 })

 let savework = async() =>{
    let workentered = document.getElementById("typeofwork").value
    let response= await fetch("http://localhost:8080/savework/" + id, {
        method: "POST",
        headers: {
           "Accept": "application/json",
           "Content-Type": "application/json"
        },
        body: JSON.stringify({
           
            type: workentered
               
        })
     }) 
     console.log(response);

     if(response.status === 201){
        window.alert("work saved successfully")
  
     }else{
        window.alert("plz check the details it seems you already have an account")
     }
 }
 work.addEventListener("click" ,savework);