let btn = document.getElementById("btn")
console.log(btn);


btn.addEventListener("click" , (e) => {
   e.preventDefault()
   let span = document.getElementsByTagName("span")
   console.log(span);
   let workId = document.getElementById("workId").value
   console.log(workId);
   let vendorId = document.getElementById("VendorId").value
   console.log(vendorId);
   let StartDate = document.getElementById("StartDate").value
   console.log(StartDate);
   
   if(workId === "")
   {
      span[1].style.display = "block"
   }
   else if(vendorId === "")
   {
    span[3].style.display = "block"
   }else if(StartDate === ""){
    span[5].style.display = "block"
   }

})

let startwork = async() => {
    let workId = document.getElementById("workId").value
    let vendorId = document.getElementById("VendorId").value
    let StartDate = document.getElementById("StartDate").value
   
    let response= await fetch("http://localhost:8080/startdate/" +workId +"/"+vendorId, {
      method: "PUT",
      headers: {
         "Accept": "application/json",
         "Content-Type": "application/json"
      },
      body: JSON.stringify({
        startDate :StartDate
        
      })
   })

   if(response.status === 302){
    window.alert("work started successfully")
    window.location.href = "http://127.0.0.1:5500/endwork.html" ;

 }else{
    window.alert("plz check the details it seems you already have an account")
 }
}

btn.addEventListener("click" ,  startwork);