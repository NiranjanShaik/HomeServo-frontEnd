let btn = document.getElementById("btn")
console.log(btn);


btn.addEventListener("click" , (e) => {
   e.preventDefault()
   let span = document.getElementsByTagName("span")
   console.log(span);
   let workId = document.getElementById("workId").value
   console.log(workId);
   let vendorId = document.getElementById("VendorId").value
   console.log(vendorId);
   let enddate = document.getElementById("enddate").value
   console.log(enddate);
   
   if(workId === "")
   {
      span[1].style.display = "block"
   }
   else if(vendorId === "")
   {
    span[3].style.display = "block"
   }else if(StartDate === ""){
    span[5].style.display = "block"
   }

})

let endwork = async() => {
    let workId = document.getElementById("workId").value
    let vendorId = document.getElementById("VendorId").value
    let enddate = document.getElementById("enddate").value
   
    let response= await fetch("http://localhost:8080/enddate/" +workId +"/"+vendorId, {
      method: "PUT",
      headers: {
         "Accept": "application/json",
         "Content-Type": "application/json"
      },
      body: JSON.stringify({
        endDate : enddate
        
      })
   })

   if(response.status === 302){
    window.alert("work ended successfully")
    window.location.href = "http://127.0.0.1:5500/savecost.html" ;

 }else{
    window.alert("plz check the details it seems you already have an account")
 }
}

btn.addEventListener("click" ,  endwork);